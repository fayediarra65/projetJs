// Liste des tâches 
const tasks = [
    {
      id: 1,
      title: "Faire mes courses",
      description: "Acheter du lait, des œufs et du pain",
      createdAt: new Date(),
      finishedAt: null,
      finished: false,
      priority: 2
    },
    {
      id: 2,
      title: "faire mon projet",
      description: "faire un projet de js",
      createdAt: new Date(),
      finishedAt: null,
      finished: false,
      priority: 1
    },
    
  ];
  
  // Exportons la liste des tâches
  module.exports = tasks;