// Import Express et la liste des tâches
const express = require('express');
const tasks = require('./database');

//une instance d'Express
const app = express();

// Middleware pour parser le JSON des requêtes
app.use(express.json());


app.post('/todos', (req, res) => {
    // Récupérons les données de la nouvelle tâche à partir du corps de la requête
    const { title, description, priority } = req.body;
  
    // Générons un nouvel identifiant unique pour la tâche
    const id = tasks.length > 0 ? tasks[tasks.length - 1].id + 1 : 1;
  
    // Créons un nouvel objet représentant la nouvelle tâche
    const newTask = {
      id,
      title,
      description,
      createdAt: new Date(),
      finishedAt: null,
      finished: false,
      priority
    };
  
    // Ajoutons la nouvelle tâche à la liste des tâches
    tasks.push(newTask);
  
    // Renvoyons la liste mise à jour des tâches en réponse à la requête
    res.json(tasks);
  });
app.put('/todos/:id', (req, res) => {
    
    // l'identifiant de la tâche à modifier
    const taskId = parseInt(req.params.id);
      
     // Recherchons  la tâche correspondante dans la liste des tâches
     const taskToUpdate = tasks.find(task => task.id === taskId);
      
    // Vérification  si la tâche existe
     if (!taskToUpdate) {
          return res.status(404).json({ message: "Tâche non trouvée" });
    }
      
    // Mettons à jour les attributs de la tâche avec les nouvelles valeurs
    taskToUpdate.title = req.body.title || taskToUpdate.title;
    taskToUpdate.description = req.body.description || taskToUpdate.description;
    taskToUpdate.finished = req.body.finished || taskToUpdate.finished;
    taskToUpdate.priority = req.body.priority || taskToUpdate.priority;
      
    // Renvoyons la tâche modifiée en réponse à la requête
    res.json(taskToUpdate);
    
});

app.get('/todos', (req, res) => {
  // la liste de toutes les tâches dans le corps de la réponse
  res.json(tasks);
});

app.get('/todos/:id', (req, res) => {
 // Récupération de l'identifiant de la tâche à afficher
 const taskId = parseInt(req.params.id);

 // Recherchons la tâche correspondante dans la liste des tâches
 const task = tasks.find(task => task.id === taskId);

 // Vérifions si la tâche est trouvée
 if (!task) {
  
   res.status(404).json({ message: 'Tâche non trouvée' });
 } else {
   // Si la tâche est trouvée, renvoyer les détails de la tâche dans la réponse
   res.json(task);
 }
});

app.delete('/todos/:id', (req, res) => {
  // id de la tâche à supprimer
  const taskId = parseInt(req.params.id);

  // Recherchons l'index de la tâche correspondante dans la liste des tâches
  const taskIndex = tasks.findIndex(task => task.id === taskId);

  
  if (taskIndex !== -1) {
    // supprimons de la liste des tâches s'il est là
    tasks.splice(taskIndex, 1);
    
    // Renvoyons la liste mise à jour des tâches en réponse à la requête
    res.json(tasks);
  } else {
    //  renvoyons une réponse avec un statut 404 , si on le trouve pas
    res.status(404).json({ message: 'Tâche non trouvée' });
  }
});



app.get('/todos/search', (req, res) => {
    // Récupérons la valeur du paramètre 'search' de la requête
    const leterm = req.query.search;
      
    // Filtrons les tâches dont le titre correspond à la valeur de recherche
    const tachefiltre = tasks.filter(task => task.title.toLowerCase().includes(leterm.toLowerCase()));
      
    // Renvoyer les tâches filtrées dans la réponse à la requête
    res.json(tachefiltre);
});


app.get('/todos/order', (req, res) => {
  // Trions les tâches par ordre de priorité
  const tachesTriees = tasks.slice().sort((tache1, tache2) => tache1.priority - tache2.priority);

  // Renvoyons les tâches triées dans la réponse à la requête
  res.json(tachesTriees);
});

// Route pour les API non trouvées (404)
app.use((req, res) => {
    res.status(404).send('not found');
  });
  
  // Démarrons le serveur
  const PORT = 3000;
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });